import pandas as pd
import plotly.express as px  # (version 4.7.0)
import plotly.graph_objects as go
import numpy as np
import re
from datetime import datetime as dt
from datetime import datetime
from dash.exceptions import PreventUpdate


import dash  # (version 1.12.0) pip install dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table

import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import load_model

import lstm

app = dash.Dash(__name__, external_stylesheets=['assets/stylesheet.css'])
server=app.server

nifty_500=pd.read_csv('ind_niftyautolist.csv') #loading nifty 500 indices as a dataframe
nifty=list(nifty_500['Symbol'])
nifty_NS=[nifty[i]+'.NS' for i in range(len(nifty))]
nifty_company_name_symbol={nifty[i]:nifty_500[nifty_500['Symbol']==nifty[i]]['Company Name'][i] for i in range (len(nifty))}

#######################################################app layout################################################################

app.layout = html.Div([

############################################################### Title and Heading ####################################################  
    html.Div([
            html.Div(
                [
                    html.Div([
                        html.H1("Indian Automobile Sector Stock Market Prediction", style={'text-align': 'center','background': '#1abc9c','padding':'10px'}),
                        html.H2('Vizualization based on Yahoo Finance API ',style={'text-align': 'center','font-size':'20px'}),
                        html.P('''    A stock market is a platform for trading of a company’s stocks and derivatives at an agreed price. Supply and demand of shares drive the stock market. In any country stock market is one of the most emerging sectors. Nowadays, many people are indirectly or directly related to this sector. Therefore, it becomes essential to know about market trends. Thus, with the development of the stock market, people are interested in forecasting stock price. But, due to dynamic nature and liable to quick changes in stock price, prediction of the stock price becomes a challenging task. Stock markets are mostly a non-parametric, non-linear, noisy and deterministic chaotic system.'''),
                        html.P('''As the technology is increasing, stock traders are moving towards to use Intelligent Trading Systems rather than fundamental analysis for predicting prices of stocks, which helps them to take immediate investment decisions. One of the main aims of a trader is to predict the stock price such that he can sell it before its value decline, or buy the stock before the price rises. The efficient market hypothesis states that it is not possible to predict stock prices and that stock behaves in the random walk. It seems to be very difficult to replace the professionalism of an experienced trader for predicting the stock price. But because of the availability of a remarkable amount of data and technological advancements we can now formulate an appropriate algorithm for prediction whose results can increase the profits for traders or investment firms.'''),   
                    ]),#headings for the dashboard
                    html.Br()
                ]
            ),

############################################################### row-1 ##############################################################  
    html.Div(
        [   
                            #############################First row Column1#####################
                            html.Div([

                                html.Br(),
                                html.H3('Company wise Line Plot',style={'text-align': 'centre','font-size':'25px'}),
                                
                                html.Div([
                                dcc.Dropdown(id="slct_comp",
                                    options=[{'label' : p, 'value' : p} for p in nifty_NS],
                                multi=False,
                                value="MARUTI.NS",
                                style={'width': "60%"},
                                placeholder="Select a Auto Company",
                                ),
                                html.P('Select the Automobile comapny to display the Line plots',style={'text-align': 'left','font-size':'10px'}),    
                                dcc.Dropdown(id="slct_cat",
                                options=[
                                    {"label": "Open","value": "Open"},
                                    {"label": "High","value": "High"},
                                    {"label": "Low","value": "Low"},
                                    {"label": "Close","value": "Close"},
                                    {"label": "Adj Close","value": "Adj Close"},
                                 {"label": "Volume","value": "Volume"}],
                                multi=False,
                                value='Close',
                                style={'width': "60%"}
                                ), 
                            html.P('Select the category',style={'text-align': 'left','font-size':'10px'}),
                        html.Div(id='output_container1',children=[]),
                        ]), 

                        html.Br(),
                        html.Div(
                            [
                            dcc.Graph(id='my_bee_map1', figure={})      
                            ]),
                        ], className= 'six columns'
                        ),
        
                        ######################################### First row Column 2 #########################################               
                            html.Div(
                            [   html.Br(),
                            html.Div([

                                html.H3('Company Wise MACD plot',style={'text-align': 'centre','font-size':'25px'}),
                                
                                dcc.Dropdown(id="slct_comp1",
                                    options=[{'label' : p, 'value' : p} for p in nifty_NS],
                                multi=False,
                                value="MARUTI.NS",
                                style={'width': "60%"},
                                placeholder="Select Company",
                                ),
                            html.P('Select the Company',style={'text-align': 'left','font-size':'10px'}),    
                            
                            html.Div(id='output_container',children=[]),
                            html.Br(),
                            html.Br(),
                            html.Br(),
                            html.P('',style={'text-align': 'left','font-size':'10px'}),
                            ]),
                            html.Div(
                            [
                            dcc.Graph(id='my_bee_map', figure={})      
                            ]),
                        ], className= 'six columns'
                    )
                    ################################ First row Column 2 Ends ########################################
                    ],className='row',style={'marginLeft': 10, 'marginRight': 10, 'marginTop': 10, 'marginBottom': 10,
                     'backgroundColor':'#F7FBFE',
                    'border': 'thin lightgrey dashed', 'padding': '4px 0px 10px 4px'}),  
            
                    ],className='ten columns offset-by-one'
                    ),

#########################################################row 2#######################################################
    html.Center([
    html.Div([
            
            ####################################Second row Column 1 ############################
            html.Div([
                html.Div([
                    html.H3('Prediction of stock Price',style={'text-align': 'centre','font-size':'25px'}),
                    dcc.Dropdown(id="name-dropdown",
                            options=[{'label' : p, 'value' : p} for p in nifty_NS],
                        multi=False,
                        style={'width': "60%"},
                        placeholder="Select a Company",
                        searchable=False
                        ),
                    html.P('Select the Company',style={'text-align': 'centre','font-size':'10px'}),
                    html.Div(id='output_container2',children=[]),
                    html.Br(),
                    html.Br(),
      

                    
                ],className='ten columns offset-by-one'),

            ])
        ])
    ])    







])                    
    


######################################################Call Backs############################################################

@app.callback(
    [Output(component_id='output_container1', component_property='children'),
    Output(component_id='my_bee_map1', component_property='figure')],
    [Input(component_id='slct_comp', component_property='value'),
     Input(component_id='slct_cat', component_property='value')]
)


def update_graph1(option_slctd,option_slctd1):

    if option_slctd1=='Volume':
            container=" "
            dff=yf.download(option_slctd, period="max")
            df1=dff[option_slctd1]
            print(max(dff[option_slctd1].values))
            fig = go.Figure()
            fig.update_layout(yaxis_range=[0,max(dff[option_slctd1].values)])

            fig.add_trace(go.Bar(x=df1.index, y=df1.values,
                    name='Volume'))
            #fig = px.bar(df1, x=df1.index, y=option_slctd1)
            fig.update_layout(
        autosize=False,
        width=700,
        height=700,
        margin=dict(
            l=50,
            r=50,
            b=100,
            t=100,
            pad=4
        ),
        paper_bgcolor="LightSteelBlue",
    )               

            fig.update_xaxes(
        rangeslider_visible=True,
        rangeselector=dict(
            buttons=list([
                dict(count=1, label="1m", step="month", stepmode="backward"),
                dict(count=6, label="6m", step="month", stepmode="backward"),
                dict(count=1, label="YTD", step="year", stepmode="todate"),
                dict(count=1, label="1y", step="year", stepmode="backward"),
                dict(step="all")
            ])
        )
    )

            return container,fig

    else:
        container=" "
        dff=yf.download(option_slctd, period="max")
        df1=dff[option_slctd1]
        fig = px.line(df1, x=df1.index, y=option_slctd1)
        fig.update_layout(
        autosize=False,
        width=700,
        height=700,
        margin=dict(
            l=50,
            r=50,
            b=100,
            t=100,
            pad=4
        ),
        paper_bgcolor="LightSteelBlue",
    )               

        fig.update_xaxes(
        rangeslider_visible=True,
        rangeselector=dict(
            buttons=list([
                dict(count=1, label="1m", step="month", stepmode="backward"),
                dict(count=6, label="6m", step="month", stepmode="backward"),
                dict(count=1, label="YTD", step="year", stepmode="todate"),
                dict(count=1, label="1y", step="year", stepmode="backward"),
                dict(step="all")
            ])
        )
    )

        return container,fig

@app.callback(
    [Output(component_id='output_container', component_property='children'),
     Output(component_id='my_bee_map', component_property='figure')],
    [Input(component_id='slct_comp1', component_property='value')]
)    

def update_graph1(option_slctd):
    
    container=" "
    dff=yf.download(option_slctd, period="max")
    dff['EMA_12']=dff['Close'].ewm(span=12,adjust=False,min_periods=0).mean()
    dff['EMA_26']=dff['Close'].ewm(span=26,adjust=False,min_periods=0).mean()
    dff['MACD']=dff['EMA_12']-dff['EMA_26']
    dff['Signal_line']=dff['MACD'].ewm(span=9,adjust=False,min_periods=0).mean()

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dff.index, y=dff['Close'].values,
                    mode='lines',
                    name='Close'))
    #fig = px.line(dff, x=dff.index, y='Close')
    fig.add_trace(go.Scatter(x=dff.index, y=dff['MACD'].values,
                    mode='lines',
                    name='MACD'))
    fig.add_trace(go.Scatter(x=dff.index, y=dff['Signal_line'].values,
                    mode='lines',
                    name='Signal'))
    fig.add_trace(go.Scatter(x=dff.index, y=[0 for i in range (len(dff['Signal_line']))],
                    mode='lines',
                    name='Base line'))

    fig.update_layout(
    autosize=False,
    width=700,
    height=700,
    margin=dict(
        l=50,
        r=50,
        b=100,
        t=100,
        pad=4
    ),
    paper_bgcolor="LightSteelBlue",
)                

    fig.update_xaxes(
    rangeslider_visible=True,
    rangeselector=dict(
        buttons=list([
            dict(count=1, label="1m", step="month", stepmode="backward"),
            dict(count=6, label="6m", step="month", stepmode="backward"),
            dict(count=1, label="YTD", step="year", stepmode="todate"),
            dict(count=1, label="1y", step="year", stepmode="backward"),
            dict(step="all")
        ])
    )
)
    return container,fig

@app.callback(
    [Output(component_id='output_container2', component_property='children')],
    [Input(component_id='name-dropdown', component_property='value')]

)    
def update_pred(option_slctd):
   
    if option_slctd:

        container=[(lstm.predict(option_slctd))]
        return container

    else:
        raise PreventUpdate()    

    


if __name__ == '__main__':
    app.run_server(debug=True)