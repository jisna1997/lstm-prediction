from sklearn.preprocessing import MinMaxScaler
import tensorflow.keras 
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM , Dense
from tensorflow.keras.layers import Dropout
from tensorflow.keras import callbacks
from tensorflow.keras.callbacks import EarlyStopping,ReduceLROnPlateau
from tqdm import tqdm
    
import datetime
import tensorflow.keras
import os
import numpy as np
import yfinance as yf

def build_model():
    lstm_model = Sequential()

    # layer - I
    lstm_model.add(LSTM(units = 50, return_sequences= True, input_shape = (10, 1)))
    # Removing overfitting 0.2 - 20% of neurons will be not connected to next layer 
    lstm_model.add(Dropout(0.2))

    # Layer - II
    lstm_model.add(LSTM(units = 50, return_sequences= True))
    lstm_model.add(Dropout(0.2))

    # Layer - III
    lstm_model.add(LSTM(units = 50,return_sequences= True))
    lstm_model.add(Dropout(0.2))

    #Layer - IV
    lstm_model.add(LSTM(units = 50))
    lstm_model.add(Dropout(0.2))

    # Regression 
    lstm_model.add(Dense(units = 1))

    lstm_model.compile(optimizer = 'Adam', loss = 'mean_squared_error', metrics = ['mean_squared_error', 
                                                                                   'mean_absolute_error'])
    return lstm_model

def predict(comp_name):
    #test2=yf.download(comp_name, start=(datetime.date.today()-datetime.timedelta(30)).isoformat(),end=datetime.date.today().isoformat())
    test2=yf.download(comp_name, period='1mo')
    dt_st=(test2['Close'].index[-1].date()+datetime.timedelta(1)).isoformat()
    model=build_model()
    model.load_weights("Auto_model/"+comp_name+".hdf5")
    input_data=test2['Close'][-10:].values.reshape(-1,1)
    scaler1 = MinMaxScaler()
    scaler1.fit(input_data)
    input_data=scaler1.transform(input_data)
    input_data = input_data.reshape(1,10,1)
    lstm_pred1 = model.predict(input_data)
    prediction1 = scaler1.inverse_transform(lstm_pred1)

    return ('The Predicted Closing price will be {} on {}' .format(np.round(prediction1)[0][0],dt_st))